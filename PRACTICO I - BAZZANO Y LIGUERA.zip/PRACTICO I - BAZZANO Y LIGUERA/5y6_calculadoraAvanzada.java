//CODIGO 4 y 5
/* Emular una calculadora de operaciones basicas usando un menu de opciones
y luego realizarle mejoras para que que permita calcular areas de: triangulos cuadrados y circulos*/

import java.util.*;

public class calculadoraAvanzada {

//FUNCIONES: SUMA, RESTA, MULTIPLICACION, DIVISION, Y AREAS

    //Funcion de Suma
    public static double sumar(double a, double b) {
        return a + b;
    }

    //Funcion de Resta
    public static double restar(double a, double b) {
        return a - b;
    }

    //Funcion de Multiplicacion
    public static double multiplicar(double a, double b) {
        return a * b;
    }

    //Funcion de Division
    public static double dividir(double a, double b) {
        return a / b;
    }

    //Funcion de Area de el Triangulo (base * altura) / 2
    public static double areaTriangulo(double base, double altura) {
        return (base * altura) / 2;
    }

    //Funcion de Area del Cuadrado (lado * lado)
    public static double cuadrado(double lado) {
        return lado * lado;
    }

    //Funcion de Area del Circulo π * radio²
    public static double circulo(double radio) {
        return Math.PI * radio * radio;
    }


    public static void main(String[] args) {

    Scanner input = new Scanner(System.in); //Leemos datos del usuario
    int op; //Variable donde guardamos la opcion elegida

//Variables para operaciones 
//Se deben declarar fuera para usarlas en todo el switch.
    double n1 = 0, n2 = 0;

    System.out.println("Bienvenido a la Calculadora");

//Bucle principal (se repite hasta elegir Salir con la opcion 8)
    do {
        
//Mostramos el menu de opciones
        System.out.println("\nEstas en el Menu de Opciones, Que deseas hacer?:");
        System.out.println("1. Sumar");
        System.out.println("2. Restar");
        System.out.println("3. Multiplicar");
        System.out.println("4. Dividir");
        System.out.println("5. Calcular el Area de un Triangulo");
        System.out.println("6. Calcular el Area de un Cuadrado");
        System.out.println("7. Calcular el Area de un Circulo");
        System.out.println("8. Salir");

        System.out.print("Elija una opcion: ");
        op = input.nextInt();

//Si la opcion es entre 1 y 4 sabemos que necesitamos que el usuario nos diga dos numeros, asi se los pedimos UNA SOLA VEZ acá y no repetimos en cada case.
    if (op >= 1 && op <= 4) {

    System.out.print("Ingrese el primer numero: ");
    n1 = input.nextDouble();

    System.out.print("Ingrese el segundo numero: ");
    n2 = input.nextDouble();
    }

//Chequeamos que opcion eligio el usuario
        switch (op) {

        case 1:
        //Cada uno de estos casos hasta el 4 usa los numeros ya solicitados antes.
            System.out.println("Resultado: " + sumar(n1, n2));
            break;

        case 2:
            System.out.println("Resultado: " + restar(n1, n2));
            break;

        case 3:
            System.out.println("Resultado: " + multiplicar(n1, n2));
            break;

        case 4:
        //En este caso tambien nos aseguramos de que el usuario no intente dividir entre cero.
            if (n2 != 0) {
            System.out.println("Resultado: " + dividir(n1, n2));
            } else {
                System.out.println("Error: no se puede dividir entre 0");
                }
            break;

        case 5:
            //Para el area del triangulo necesitamos base y altura entonces si el usuario selecciona esta opcion le solicitamos los datos aparte
            System.out.print("Ingrese la base: ");
            double base = input.nextDouble();

            System.out.print("Ingrese la altura: ");
            double altura = input.nextDouble();

            System.out.println("Area del triangulo: " + areaTriangulo(base, altura));
            break;

        case 6:
        //Para el cuadrado solo necesitamos un valor que es el lado, tambien lo solicitamos aparte
            System.out.print("Ingrese el lado del cuadrado: ");
            double lado = input.nextDouble();

            System.out.println("Area del cuadrado: " + cuadrado(lado));
            break;

        case 7:
        //Para el circulo solo necesitamos el radio, tambien lo pedimos aparte
            System.out.print("Ingrese el radio del circulo: ");
            double radio = input.nextDouble();

            System.out.println("Area del círculo: " + circulo(radio));
            break;

            case 8:
            //Opcion de salida para el usuario
                System.out.println("Salida Exitosa, gracias por usar nuestra calculadora!");
                    break;

            default:
            //Si el usuario ingresa algo invalido
                System.out.println("Opcion invalida");
            }

        } while (op != 8); //Se repite hasta elegir salir

        input.close(); //Cerramos Scanner
    }
}