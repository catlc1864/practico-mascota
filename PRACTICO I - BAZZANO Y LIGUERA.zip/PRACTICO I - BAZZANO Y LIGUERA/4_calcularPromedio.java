//CODIGO 4
//DADAS LAS NOTAS DE UN ESTUDIANTE CALCULAR SU PROMEDIO

import java.util.*;

public class calcularPromedio{

//Funcion para calcular el promedio
    public static double promedio(double n1, double n2, double n3) {
        return (n1 + n2 + n3) / 3;
}

public static void main(String[] args) {

Scanner input = new Scanner(System.in);

//Declaro las variables de las notas
    double nota1;
    double nota2;
    double nota3;
    
    System.out.println("Ingrese la calificacion de Matematicas: ");
    nota1 = input.nextDouble();

    System.out.println("Ingrese la calificacion de Lengua: ");
    nota2 = input.nextDouble();

    System.out.println("Ingrese la calificacion de Programacion: ");
    nota3 = input.nextDouble();

//Doy el promedio de el estudiante
    System.out.println("El promedio del estudiante es: " + promedio(nota1, nota2, nota3));
    }
}