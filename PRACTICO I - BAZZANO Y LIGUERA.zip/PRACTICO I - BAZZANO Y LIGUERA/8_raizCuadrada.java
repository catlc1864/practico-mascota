//CODIGO 8
//REALIZAR UN ALGORITMO QUE CALCULE LA RAIZ CUADRADA DE UN NUMERO CUALQUIERA

import java.util.*;

public class raizCuadrada {

//Funcion para calcular la raiz cuadrada
    public static double raiz(double a) {
        return Math.sqrt(a); //Forma mas practica de calcular la raiz cuadrada de un numero
}
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        double numero;
        System.out.println("Ingrese un numero: ");
        numero = input.nextDouble();

        System.out.println("La raiz cuadrada es: " + raiz(numero));
    }
}