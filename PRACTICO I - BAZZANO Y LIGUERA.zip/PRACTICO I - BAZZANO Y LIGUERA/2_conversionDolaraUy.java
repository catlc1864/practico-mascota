//CODIGO 2
//DADO EL VALOR EN DOLARES DE UN PRODUCTO, MOSTRAR SU EQUIVALENTE EN PESOS URUGUAYOS

import java.util.*;
public class conversionDolaraUy {
    
    public static double multiplicar (double a, double b){
        return a*b;
    }

    public static void main (String []args) {
        Scanner input=new Scanner (System.in);
        double x=40.34;

        double y;
        System.out.println("Ingrese el valor de el producto en dolares: ");
        y= input.nextDouble();

        System.out.println("Su monto convertido en pesos uruguayos es: "+multiplicar(y,x));

    }
}
