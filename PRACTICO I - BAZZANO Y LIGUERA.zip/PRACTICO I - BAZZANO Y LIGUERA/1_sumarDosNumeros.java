//CODIGO 1
//INGRESAR 2 NUMEROS, SUMARLOS Y CALCULAR SU PRODUCTO

import java.util.*;

public class sumarDosNumeros{
    
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);

        int x;
        System.out.println("Ingrese el primer numero: ");
        x = input.nextInt();

        int y;
        System.out.println("Ingrese el segundo numero: ");
        y = input.nextInt();

        System.out.println("La suma es: " + sumar(x, y));
        System.out.println("El producto es: " + multiplicar(x, y));
}

//Funcion para sumar
    public static int sumar(int a, int b) {
        return a + b;
}

//Funcion para calcular el producto
    public static int multiplicar(int a, int b) {
        return a * b;
    }
}