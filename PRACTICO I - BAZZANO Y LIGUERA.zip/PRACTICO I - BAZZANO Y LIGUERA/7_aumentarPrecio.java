//CODIGO 7
//AUMENTAR EN UN 20% EL PRECIO DE UN PRODUCTO CUALQUIERA QUE SE INGRESA POR EL TECLADO

import java.util.*;

public class aumentarPrecio {

//Funcion para hacer el aumento del 20%
    public static double aumento(double precio) {
        return precio * 1.20;
}
   public static void main(String[] args){

        Scanner input = new Scanner(System.in);

        double precio;
        System.out.println("Ingrese el precio del producto: ");
        precio = input.nextDouble();

        System.out.println("El nuevo precio con aumento es: " + aumento(precio));
    }
}